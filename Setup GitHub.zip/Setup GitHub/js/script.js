/*
Ashlea Andrews
Test JS file
May the 4th be with you 2015
 */

//alert("Testing 1, 2, 3 ")